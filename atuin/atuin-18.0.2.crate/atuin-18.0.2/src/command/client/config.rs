use atuin_client::settings::Settings;

pub fn run() {
    println!("{}", Settings::example_config());
}
