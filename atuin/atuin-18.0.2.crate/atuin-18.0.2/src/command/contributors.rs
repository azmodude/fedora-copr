static CONTRIBUTORS: &str = include_str!("CONTRIBUTORS");

pub fn run() {
    println!("\n{CONTRIBUTORS}");
}
